import React from 'react';
import { Heart } from 'lucide-react';
import { motion } from 'framer-motion';

interface HeartButtonProps {
  onClick: () => void;
  disabled?: boolean;
}

export const HeartButton: React.FC<HeartButtonProps> = ({ onClick, disabled }) => {
  return (
    <motion.button
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      className="bg-pink-500 text-white px-8 py-4 rounded-full flex items-center gap-2 disabled:opacity-50"
      onClick={onClick}
      disabled={disabled}
    >
      <Heart className="w-6 h-6" />
      <span className="font-dancing-script text-xl">Yes</span>
    </motion.button>
  );
};