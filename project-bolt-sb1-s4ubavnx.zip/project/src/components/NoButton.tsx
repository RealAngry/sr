import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface NoButtonProps {
  onClick: () => void;
  position: { x: number; y: number };
}

export const NoButton: React.FC<NoButtonProps> = ({ onClick, position }) => {
  return (
    <motion.button
      initial={false}
      animate={{
        x: position.x,
        y: position.y,
        transition: { type: "spring", duration: 0.5 }
      }}
      className="absolute bg-gray-400 text-white px-8 py-4 rounded-full font-dancing-script text-xl"
      onClick={onClick}
    >
      No
    </motion.button>
  );
};