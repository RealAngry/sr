import React from 'react';
import { motion } from 'framer-motion';

const memories = [
  {
    caption: "Our first chat...",
    image: "https://images.unsplash.com/photo-1516534775068-ba3e7458af70?auto=format&fit=crop&q=80&w=800"
  },
  {
    caption: "That time you laughed so hard...",
    image: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&q=80&w=800"
  },
  {
    caption: "The way you always listen...",
    image: "https://images.unsplash.com/photo-1522673607200-164d1b6ce486?auto=format&fit=crop&q=80&w=800"
  },
  {
    caption: "Our journey so far...",
    image: "https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?auto=format&fit=crop&q=80&w=800"
  }
];

export const MemorySlideshow: React.FC = () => {
  return (
    <div className="w-full max-w-2xl mx-auto space-y-8">
      {memories.map((memory, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.5 }}
          className="relative rounded-lg overflow-hidden shadow-xl"
        >
          <img
            src={memory.image}
            alt={memory.caption}
            className="w-full h-64 object-cover"
          />
          <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-4">
            <p className="font-dancing-script text-2xl text-center">{memory.caption}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};