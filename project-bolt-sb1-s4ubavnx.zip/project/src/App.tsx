import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import useSound from 'use-sound';
import { Heart, Sparkles, Stars, Music, Moon } from 'lucide-react';
import { HeartButton } from './components/HeartButton';
import { NoButton } from './components/NoButton';
import { MemorySlideshow } from './components/MemorySlideshow';
import { FloatingHearts } from './components/FloatingHearts';

import '@fontsource/dancing-script';
import '@fontsource/pacifico';
import '@fontsource/poppins';

const noButtonMessages = [
  "Are you sure?",
  "But who will laugh at my lame jokes?",
  "I'll give you my Netflix password...",
  "You know I can't survive without you...",
  "What if I say you're the best thing that ever happened to me?",
  "What if I promise to support you no matter what?",
  "I'll let you choose the movie every Friday...",
  "Come on... you know you love me too...",
  "Please? 🥺",
  "Last chance...",
  "I'll learn to cook for you...",
  "I promise to always be there...",
  "You're my sunshine on rainy days..."
];

const poems = [
  "Every moment with you is a gift,\nEvery smile a treasure to lift.",
  "In your eyes I see my future bright,\nIn your heart I find my delight.",
  "Like stars that guide us through the night,\nYour love makes everything just right."
];

function App() {
  const [stage, setStage] = useState(0);
  const [noAttempts, setNoAttempts] = useState(0);
  const [showMemories, setShowMemories] = useState(false);
  const [noButtonPosition, setNoButtonPosition] = useState({ x: 0, y: 0 });
  const [currentPoem, setCurrentPoem] = useState(0);
  const [showPoem, setShowPoem] = useState(false);
  
  const [playHeartbeat] = useSound('/heartbeat.mp3', { volume: 0.5 });
  const [playSuccess] = useSound('/success.mp3', { volume: 0.5 });

  useEffect(() => {
    if (stage === 0) {
      const timer = setTimeout(() => setStage(1), 1000);
      return () => clearTimeout(timer);
    }
  }, [stage]);

  useEffect(() => {
    if (stage === 2) {
      const poemInterval = setInterval(() => {
        setCurrentPoem((prev) => (prev + 1) % poems.length);
        setShowPoem(true);
        setTimeout(() => setShowPoem(false), 3000);
      }, 4000);
      return () => clearInterval(poemInterval);
    }
  }, [stage]);

  const handleNoClick = () => {
    if (noAttempts >= noButtonMessages.length - 1) {
      const x = Math.random() * (window.innerWidth - 200);
      const y = Math.random() * (window.innerHeight - 100);
      setNoButtonPosition({ x, y });
    }
    setNoAttempts(prev => prev + 1);
    playHeartbeat();
  };

  const handleYesClick = () => {
    playSuccess();
    setStage(2);
    setTimeout(() => setShowMemories(true), 2000);
  };

  return (
    <div className={`min-h-screen transition-all duration-1000 ${
      stage === 2 ? 'sunset-bg' : 'gradient-bg'
    }`}>
      <FloatingHearts visible={stage === 2} />
      
      <div className="container mx-auto px-4 py-12 relative">
        <AnimatePresence>
          {stage >= 1 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center space-y-8"
            >
              {stage === 1 ? (
                <>
                  <motion.div className="absolute top-4 right-4">
                    <Moon className="w-8 h-8 text-white opacity-50" />
                  </motion.div>
                  
                  <motion.h1
                    className="text-4xl md:text-6xl font-dancing-script text-white mb-12"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                  >
                    I... Just wanna say that... I like you... a lot ❤️
                  </motion.h1>
                  
                  <motion.div
                    className="flex flex-col md:flex-row items-center justify-center gap-8"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 1.5 }}
                  >
                    <HeartButton onClick={handleYesClick} />
                    <NoButton
                      onClick={handleNoClick}
                      position={noButtonPosition}
                    />
                  </motion.div>

                  {noAttempts > 0 && (
                    <motion.p
                      key={noAttempts}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-2xl font-pacifico text-white mt-8"
                    >
                      {noButtonMessages[noAttempts % noButtonMessages.length]}
                    </motion.p>
                  )}
                </>
              ) : (
                <>
                  <motion.div className="absolute top-4 right-4 flex space-x-4">
                    <Stars className="w-8 h-8 text-white opacity-50" />
                    <Music className="w-8 h-8 text-white opacity-50" />
                  </motion.div>

                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="space-y-8"
                  >
                    <h1 className="text-6xl font-dancing-script text-white mb-4">
                      I knew you loved me! ❤️
                    </h1>
                    <p className="text-3xl font-pacifico text-white">
                      You make my world brighter...
                    </p>
                    <p className="text-4xl font-dancing-script text-white">
                      Will you be my reason to smile every day?
                    </p>

                    <AnimatePresence mode="wait">
                      {showPoem && (
                        <motion.p
                          key={currentPoem}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -20 }}
                          className="text-2xl font-dancing-script text-white italic"
                          style={{ whiteSpace: 'pre-line' }}
                        >
                          {poems[currentPoem]}
                        </motion.p>
                      )}
                    </AnimatePresence>
                  </motion.div>

                  {showMemories && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="mt-12"
                    >
                      <MemorySlideshow />
                    </motion.div>
                  )}

                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="mt-8 bg-pink-500 text-white px-8 py-4 rounded-full font-dancing-script text-xl"
                    onClick={() => alert("You're not just special... you're my everything. ❤️")}
                  >
                    Click for a Surprise
                  </motion.button>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export default App;